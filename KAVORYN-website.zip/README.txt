# KAVORYN website

Starter responsive website for a health + technology affiliate and dropshipping brand.

Before launch:
- Replace sample products/prices.
- Replace placeholder affiliate links with approved affiliate URLs.
- Connect dropshipping catalog/fulfillment.
- Add real legal pages and contact details.
- Verify trademark/domain availability before commercial use.
- Avoid unsupported medical claims.
